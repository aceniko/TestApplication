package com.testapplication.constants;

public final class Constants {

    //DEMO USER PASS
    public final static String USER_NAME = "admin";
    public final static String PASSWORD = "123qwe";

    //auth header name
    public final static String AUTHORIZATION = "Authorization";

    //getall products query params
    public final static String SKIP_COUNT = "SkipCount";
    public final static String MAX_RESULT_COUNT = "MaxResultCount";
}
