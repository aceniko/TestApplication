package com.testapplication.ui.fragment;

public class CreateProductFragment {
}
